package com.core;

public class Location {
	
    //Variables    
    private String name;

    //Constructor
    public Location(String name){
	this.name = name;
    }

    //get methods
    public String getName(){
	return name;
    }

    //set method
    public void setName(String name){
	this.name = name;
    }
}
