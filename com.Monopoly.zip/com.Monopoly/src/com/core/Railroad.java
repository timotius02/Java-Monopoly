package com.core;

public class Railroad extends Property{
	
	//variables
	
	
	//constructor
	public Railroad(String name, int propertyPrice, int mortgage, int rent){
		super(name, propertyPrice, mortgage, rent);
	}
	
}
