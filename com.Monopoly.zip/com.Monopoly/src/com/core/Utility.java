package com.core;

public class Utility extends Property{

	//Constructor
	public Utility(String name, int propertyPrice, int mortgage, int rent){  
		super(name, propertyPrice, mortgage, rent);

	}
	

}


